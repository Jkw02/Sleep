Project documentation:
* [x] Introduction - aims and objectives, key question, roadmap of the report - LR
* [x] Background of the project - overview of sleep as a topic - LR
* [x] Specifications of the project - tech and non-tech - AS
* [x] Implementation - roles of people in the team, what tools used, agile development, challenges - LR
* [x] Data collection - Describe how data was sourced, cleaned, pre-processed, etc. - LR
* [x] Explain findings - LR

Python coding:
* [x] Cleaning and transforming data - LR
* [x] Visualizations - AS & JC & FS
* [x] Analysis of visualizations - AS

Other:
* [x] API used to fetch data - ML
* [x] Presentation slides - JC
